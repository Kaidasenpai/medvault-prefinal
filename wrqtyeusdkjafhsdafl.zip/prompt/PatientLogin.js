import React, { useState, useEffect } from 'react';
import { ethers } from 'ethers';
import './PatientLogin.css';
import patientIcon from './patient.png';
import contractABI from './abis/MedVaultRecords.json'; // Ensure the correct path

const PatientLogin = ({ navigate }) => {
  const [walletAddress, setWalletAddress] = useState('');
  const [contract, setContract] = useState(null);

  useEffect(() => {
    const checkMetaMaskConnection = async () => {
      if (window.ethereum) {
        try {
          await window.ethereum.request({ method: 'eth_requestAccounts' });
          const provider = new ethers.providers.Web3Provider(window.ethereum);
          const signer = provider.getSigner();
          const address = await signer.getAddress();
          setWalletAddress(address);

          const contractAddress = '0x5FbDB2315678afecb367f032d93f642f64180aa3'; // Replace with your contract address
          const checksummedAddress = ethers.utils.getAddress(contractAddress);
          const contractInstance = new ethers.Contract(checksummedAddress, contractABI, signer);
          setContract(contractInstance);
        } catch (error) {
          console.error('User denied account access or MetaMask is not installed', error);
        }
      } else {
        alert('MetaMask is not installed. Please install it to use this feature.');
      }
    };

    checkMetaMaskConnection();
  }, []);

  const handleLogin = async () => {
    if (!walletAddress) {
      alert('No wallet connected');
      return;
    }

    if (!contract) {
      console.error('Contract is not set');
      return;
    }

    try {
      // Fetching a reasonable range of patient IDs (assuming IDs are sequential)
      let patientFound = false;
      for (let i = 1; i <= 100; i++) {
        try {
          const patient = await contract.patients(i);
          console.log(`Fetched patient ${i}:`, patient); // Debugging information
          if (patient.patientAddress.toLowerCase() === walletAddress.toLowerCase()) {
            navigate('patientPage', { state: { patient } });
            patientFound = true;
            break;
          }
        } catch (error) {
          console.error(`Error fetching patient with ID ${i}:`, error);
          break; // Break if fetching patient fails, assuming IDs are sequential and contiguous
        }
      }
      if (!patientFound) {
        alert('No patient found with the connected wallet address');
      }
    } catch (error) {
      console.error('Error fetching patient data:', error);
      alert('Error fetching patient data');
    }
  };

  return (
    <div className="login">
      <div className="login__content">
        <div className="login__button-wrapper">
          <img src={patientIcon} alt="Patient" className="login__icon" />
          <input
            type="text"
            placeholder="Wallet Address"
            value={walletAddress}
            readOnly
            className="login__input"
          />
          <button onClick={handleLogin} className="login__button">Login</button>
        </div>
      </div>
    </div>
  );
};

export default PatientLogin;
